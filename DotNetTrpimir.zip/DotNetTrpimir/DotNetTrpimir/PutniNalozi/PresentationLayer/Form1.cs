﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccessLayer;

namespace PresentationLayer
{
    public partial class Form1 : Form
    {
        private PutniNaloziRepository naloziRepo = new PutniNaloziRepository();
        private BindingSource _prijevozBindingSource = new BindingSource();
        private BindingSource _zaposleniciBindingSource = new BindingSource();

        private int _odabraniTipPrijevoza = -1; //jos nista nije odabrano 
        public Form1()
        {
            _prijevozBindingSource.DataSource = naloziRepo.DajPrijevoz();
            _zaposleniciBindingSource.DataSource = naloziRepo.DajZaposlenike();
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TipPrijevozaCombobox.DataSource = _prijevozBindingSource;
            zaposleniciDataGrid.DataSource = _zaposleniciBindingSource;
            // ikona za brisanje zaposlenika
            DataGridViewImageColumn delete_button = new DataGridViewImageColumn();
            delete_button.Image = Image.FromFile("C:/DotNetTrpimir/PutniNalozi/delete.png");
            delete_button.Width = 20;
            delete_button.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            zaposleniciDataGrid.Columns.Add(delete_button);

            zaposleniciDataGrid.AutoGenerateColumns = false; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(TipPrijevozaCombobox.Text == "Svi prijevozi")
            {
                MessageBox.Show("Birajte ponovo");
            }
            else
            {
                PutniNaloziForm naloziForm = new PutniNaloziForm(_odabraniTipPrijevoza);
                naloziForm.Show();
            }
        }

        private void TipPrijevozaCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            _odabraniTipPrijevoza = TipPrijevozaCombobox.SelectedIndex; // mijenja se po indexu odabira
        }

        private void pretraziZaposlenika_Click(object sender, EventArgs e)
        {
            var putniNalozi = naloziRepo.FiltrirajZaposlenike(textBoxIme.Text, textBoxPrezime.Text, Convert.ToInt32(numericUpDown1.Value));
            zaposleniciDataGrid.DataSource = putniNalozi;

            if(!putniNalozi.Any())
            {
                MessageBox.Show("Nije pronađen niti jedan zaposlenik");
            }
        }
    }
}
