﻿namespace PresentationLayer
{
    partial class PutniNaloziForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.naloziDataGrid = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prijevozId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prezime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.polaziste = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.odrediste = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datumOdlaska = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datumPovratka = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trajanje = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipPrijevoza = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.naloziDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // naloziDataGrid
            // 
            this.naloziDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.naloziDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.prijevozId,
            this.prezime,
            this.ime,
            this.polaziste,
            this.odrediste,
            this.datumOdlaska,
            this.datumPovratka,
            this.trajanje,
            this.tipPrijevoza});
            this.naloziDataGrid.Location = new System.Drawing.Point(12, 21);
            this.naloziDataGrid.Name = "naloziDataGrid";
            this.naloziDataGrid.Size = new System.Drawing.Size(837, 408);
            this.naloziDataGrid.TabIndex = 0;
            // 
            // id
            // 
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "Id";
            this.id.Name = "id";
            this.id.Visible = false;
            // 
            // prijevozId
            // 
            this.prijevozId.DataPropertyName = "prijevozId";
            this.prijevozId.HeaderText = "prijevoz id";
            this.prijevozId.Name = "prijevozId";
            this.prijevozId.Visible = false;
            // 
            // prezime
            // 
            this.prezime.DataPropertyName = "prezime";
            this.prezime.HeaderText = "Prezime";
            this.prezime.Name = "prezime";
            // 
            // ime
            // 
            this.ime.DataPropertyName = "ime";
            this.ime.HeaderText = "Ime";
            this.ime.Name = "ime";
            // 
            // polaziste
            // 
            this.polaziste.DataPropertyName = "polaziste";
            this.polaziste.HeaderText = "Polaziste";
            this.polaziste.Name = "polaziste";
            // 
            // odrediste
            // 
            this.odrediste.DataPropertyName = "odrediste";
            this.odrediste.HeaderText = "Odrediste";
            this.odrediste.Name = "odrediste";
            // 
            // datumOdlaska
            // 
            this.datumOdlaska.DataPropertyName = "datumOdlaska";
            this.datumOdlaska.HeaderText = "Datum odlaska";
            this.datumOdlaska.Name = "datumOdlaska";
            // 
            // datumPovratka
            // 
            this.datumPovratka.DataPropertyName = "datumPovratka";
            this.datumPovratka.HeaderText = "Datum povratka";
            this.datumPovratka.Name = "datumPovratka";
            // 
            // trajanje
            // 
            this.trajanje.DataPropertyName = "trajanje";
            this.trajanje.HeaderText = "Trajanje";
            this.trajanje.Name = "trajanje";
            // 
            // tipPrijevoza
            // 
            this.tipPrijevoza.DataPropertyName = "tipoviPrijevoza";
            this.tipPrijevoza.HeaderText = "Tip prijevoza";
            this.tipPrijevoza.Name = "tipPrijevoza";
            // 
            // PutniNaloziForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 434);
            this.Controls.Add(this.naloziDataGrid);
            this.Name = "PutniNaloziForm";
            this.Text = "PutniNalozi";
            this.Load += new System.EventHandler(this.PutniNalozi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.naloziDataGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView naloziDataGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn prijevozId;
        private System.Windows.Forms.DataGridViewTextBoxColumn prezime;
        private System.Windows.Forms.DataGridViewTextBoxColumn ime;
        private System.Windows.Forms.DataGridViewTextBoxColumn polaziste;
        private System.Windows.Forms.DataGridViewTextBoxColumn odrediste;
        private System.Windows.Forms.DataGridViewTextBoxColumn datumOdlaska;
        private System.Windows.Forms.DataGridViewTextBoxColumn datumPovratka;
        private System.Windows.Forms.DataGridViewTextBoxColumn trajanje;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipPrijevoza;
    }
}