﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccessLayer;

namespace PresentationLayer
{
    public partial class PutniNaloziForm : Form
    {
        private PutniNaloziRepository naloziRepo = new PutniNaloziRepository();
        private BindingSource _naloziBindingSource = new BindingSource();
        public PutniNaloziForm(int idTipaPrijevoza)
        {
            _naloziBindingSource.DataSource = naloziRepo.FiltrirajNaloge(idTipaPrijevoza);
            InitializeComponent();
        }

        private void PutniNalozi_Load(object sender, EventArgs e)
        {
            naloziDataGrid.DataSource = _naloziBindingSource; 
        }
    }
}
