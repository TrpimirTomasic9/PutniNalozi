﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;


namespace ConsoleAppTester
{
    class Program
    {
        static void Main(string[] args)
        {

            var nalogRepo = new PutniNaloziRepository();
            var gradovi = nalogRepo.DohvatiGradove();

            foreach (var grad in gradovi)
            {
                Console.WriteLine(grad.id + " " + grad.naziv);
            }
            Console.ReadKey();

        }
    }
}
