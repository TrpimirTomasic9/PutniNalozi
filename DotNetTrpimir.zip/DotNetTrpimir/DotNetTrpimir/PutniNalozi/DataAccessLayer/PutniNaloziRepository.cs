﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer.Entities;
using DataAccessLayer.ViewModel;
using Newtonsoft.Json.Linq;

namespace DataAccessLayer
{
    public class PutniNaloziRepository
    {
        public List<PutniNalozi> putniNalozi = new List<PutniNalozi>();
        public List<Zaposlenici> zaposlenici = new List<Zaposlenici>();
        public List<TipoviPrijevoza> tipoviPrijevoza = new List<TipoviPrijevoza>();
        public List<Gradovi> gradovi = new List<Gradovi>();
        public List<PutniNaloziVM> _putniNalozi = new List<PutniNaloziVM>();
        public List<ZaposleniciVM> _zaposlenici = new List<ZaposleniciVM>();

        public PutniNaloziRepository()
        {
            putniNalozi = DohvatiNaloge();
            zaposlenici = DohvatiZaposlenike();
            tipoviPrijevoza = DohvatiTipovePrijevoza();
            gradovi = DohvatiGradove();
            _putniNalozi = DajNaloge();
            _zaposlenici = DajZaposlenike();
        }
        public List<PutniNalozi> DohvatiNaloge()
        {
            List<PutniNalozi> putniNalozi = new List<PutniNalozi>();
            // ucitavanje json datoteke u string varijablu 
            StreamReader oSr = new StreamReader("putni_nalozi.json"); 
            string json = "";
            using (oSr)
            {
                json = oSr.ReadToEnd();
            }

            JObject jsonObject = JObject.Parse(json);
            var oPutniNalozi = jsonObject["PutniNalozi"].ToList(); //preko jObject-a spremam elemente u listu

            for (int i = 0; i < oPutniNalozi.Count; i++)
            {
                //kreiram objekt klase kojeg spremam u listu
                putniNalozi.Add(new PutniNalozi
                {
                    id = (int)oPutniNalozi[i]["id"],
                    zaposlenik_id = (int)oPutniNalozi[i]["zaposlenik_id"],
                    prijevoz_id = (int)oPutniNalozi[i]["prijevoz_id"],
                    polaziste_id= (int)oPutniNalozi[i]["polaziste_id"],
                    odrediste_id = (int)oPutniNalozi[i]["odrediste_id"],
                    datum_odlaska = (string)oPutniNalozi[i]["datum_odlaska"],
                    datum_povratka = (string)oPutniNalozi[i]["datum_povratka"]
                });
            }
            return putniNalozi;
        }
        public List<Zaposlenici> DohvatiZaposlenike()
        {
            List<Zaposlenici> zaposlenici = new List<Zaposlenici>();

            StreamReader oSr = new StreamReader("putni_nalozi.json");
            string json = "";
            using (oSr)
            {
                json = oSr.ReadToEnd();
            }
            JObject jsonObject = JObject.Parse(json);
            var oZaposlenici = jsonObject["Zaposlenici"].ToList();
            for (int i = 0; i < oZaposlenici.Count; i++)
            {
                zaposlenici.Add(new Zaposlenici
                {
                    id = (int)oZaposlenici[i]["id"],
                    ime = (string)oZaposlenici[i]["ime"],
                    prezime = (string)oZaposlenici[i]["prezime"]
                   
                });
            }
            return zaposlenici;

        }
        public List<TipoviPrijevoza> DohvatiTipovePrijevoza()
        {
            List<TipoviPrijevoza> tipoviPrijevoza = new List<TipoviPrijevoza>();

            StreamReader oSr = new StreamReader("putni_nalozi.json");
            string json = "";
            using (oSr)
            {
                json = oSr.ReadToEnd();
            }
            JObject jsonObject = JObject.Parse(json);
            var oTipoviPrijevoza = jsonObject["TipoviPrijevoza"].ToList();

            for (int i = 0; i < oTipoviPrijevoza.Count; i++)
            {
                tipoviPrijevoza.Add(new TipoviPrijevoza
                {
                    id = (int)oTipoviPrijevoza[i]["id"],
                    naziv = (string)oTipoviPrijevoza[i]["naziv"]

                });
            }
            return tipoviPrijevoza;
        }
        public List<Gradovi> DohvatiGradove()
        {
            List<Gradovi> gradovi = new List<Gradovi>();

            StreamReader oSr = new StreamReader("putni_nalozi.json");
            string json = "";
            using (oSr)
            {
                json = oSr.ReadToEnd();
            }
            JObject jsonObject = JObject.Parse(json);
            var oTipoviPrijevoza = jsonObject["Gradovi"].ToList();
            for (int i = 0; i < oTipoviPrijevoza.Count; i++)
            {
                gradovi.Add(new Gradovi
                {
                    id = (int)oTipoviPrijevoza[i]["id"],
                    naziv = (string)oTipoviPrijevoza[i]["naziv"]
                });
            }
            return gradovi;
        }
        // ------ 1. zadatak
        public List<string> DajPrijevoz()
        {
            var tipPrijevoza = DohvatiTipovePrijevoza();
            var prijevozi = tipPrijevoza.Where(x => !string.IsNullOrEmpty(x.naziv)).Select(x => x.naziv).ToList();
            prijevozi.Insert(0, "Svi prijevozi");
            return prijevozi;
        }
        // Ispis naloga
        public List<PutniNaloziVM> DajNaloge()
        {
            var _nalozi = putniNalozi.Select(nalog => new PutniNaloziVM
            {
                prezime = zaposlenici.Where(zap => zap.id == nalog.zaposlenik_id).Select(zap => zap.prezime).FirstOrDefault(),
                ime = zaposlenici.Where(zap => zap.id == nalog.zaposlenik_id).Select(zap => zap.ime).FirstOrDefault(),
                polaziste = gradovi.Where(grad => grad.id == nalog.polaziste_id).Select(grad => grad.naziv).FirstOrDefault(),
                odrediste = gradovi.Where(grad => grad.id == nalog.odrediste_id).Select(grad => grad.naziv).FirstOrDefault(),
                datumOdlaska = (nalog.datum_odlaska),
                datumPovratka = (nalog.datum_povratka),
                trajanje = Trajanje(nalog.datum_odlaska, nalog.datum_povratka),
                prijevozId = (nalog.prijevoz_id),
                tipoviPrijevoza = tipoviPrijevoza.Where(tip => tip.id == nalog.prijevoz_id).Select(tip => tip.naziv).FirstOrDefault()
            }).ToList();
            return _nalozi;
        }
        public string Trajanje(string datumOdlaska, string datumPovratka)
        {
            DateTime oDateOdlazak = DateTime.ParseExact(datumOdlaska, "dd.mm.yyyy", null);
            DateTime oDatePovratak = DateTime.ParseExact(datumPovratka, "dd.mm.yyyy", null);
            TimeSpan value = oDatePovratak.Subtract(oDateOdlazak);
            return (value.Duration().Days + 1).ToString();

            /*
            var trajanje = "";
            if (datumOdlaska == datumPovratka)
            {
                trajanje = "1 dan";
                return trajanje;
            }
            else
            {
                //string odlazak = datumOdlaska;
                //string povratak = datumPovratka;
                //DateTime myDateOdlazak = DateTime.Parse(odlazak);
                //DateTime myDateDolazak = DateTime.Parse(povratak);
                //TimeSpan diff = myDateDolazak - myDateOdlazak;
                //diff.ToString();

                



            }*/
            return "";
                //var trajanje = "";
                //if (datumOdlaska == datumPovratka)
                //{
                //    trajanje = "1 dan";

                //}
                //else
                //{
                //    trajanje = "Više dana";
                //}

                //return trajanje;
        }

        //filtriranje po odabiru iz comboboxa
        public List<PutniNaloziVM> FiltrirajNaloge(int idTipaPrijevoza)
        {
            var nalozi = _putniNalozi.Where(nalog => true);
            //ako je tip prijevoza veci ili jednak index-u 0, usporedujem parametan idTipaPrijevoza i prijevozId iz klase te spremam u listu za ispis putnih naloga
            if(idTipaPrijevoza >= 0)
            {
                nalozi = _putniNalozi.Where(nalog => nalog.prijevozId == idTipaPrijevoza).ToList();
            }
            return nalozi.ToList();
        }
        // ------ 2. zadatak
        public List<ZaposleniciVM> DajZaposlenike()
        {
            var _zaposlenici = zaposlenici.Select(zaposlenik => new ZaposleniciVM
            {
                id = zaposlenici.Where(zap => zap.id == zaposlenik.id).Select(zap => zap.id).FirstOrDefault(),
                prezime = zaposlenici.Where(zap => zap.id == zaposlenik.id).Select(zap => zap.prezime).FirstOrDefault(),
                ime = zaposlenici.Where(zap => zap.id == zaposlenik.id).Select(zap => zap.ime).FirstOrDefault(),
                brojPutnihNaloga = BrojNaloga(zaposlenik.id)
            }).OrderBy(zaposlenik => zaposlenik.brojPutnihNaloga).ToList();
            return _zaposlenici;
        }
        public int BrojNaloga(int zaposlenikId)
        {
            var brojNaloga = 0; 
            for(int i = 0; i < putniNalozi.Count(); i++)
            {
                for(int j = 0; j < zaposlenici.Count(); j++)
                {
                    if(putniNalozi[i].zaposlenik_id == zaposlenikId && zaposlenici[j].id == zaposlenikId)
                    {
                        brojNaloga++
;                   }
                }
            }
            return brojNaloga;
        }
       // 3. zadatak
        public List<ZaposleniciVM> FiltrirajZaposlenike(string Ime, string Prezime, int BrojNaloga)
        {
            var zaposlenik = _zaposlenici.Where(zap => true);
            if (!string.IsNullOrEmpty(Ime))
            {
                zaposlenik = _zaposlenici.Where(zap => zap.ime == Ime).ToList();
            }
            if (!string.IsNullOrEmpty(Prezime))
            {
                zaposlenik = _zaposlenici.Where(zap => zap.prezime == Prezime).ToList();
            }
            if (BrojNaloga != 0)
            {
                zaposlenik = _zaposlenici.Where(zap => zap.brojPutnihNaloga == BrojNaloga).ToList();
            }
            return zaposlenik.ToList();
        }
    }
}
