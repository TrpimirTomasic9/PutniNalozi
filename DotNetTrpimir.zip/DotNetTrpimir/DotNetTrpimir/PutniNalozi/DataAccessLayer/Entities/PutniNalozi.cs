﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Entities
{
    public class PutniNalozi
    {
        public int id { get; set; }
        public int zaposlenik_id { get; set; }
        public int prijevoz_id { get; set; }
        public int polaziste_id { get; set; }
        public int odrediste_id { get; set; }
        public string datum_odlaska { get; set; }
        public string datum_povratka { get; set; }
    }
}
