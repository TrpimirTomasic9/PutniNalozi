﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.ViewModel
{
    public class PutniNaloziVM
    {
        public int id { get; set; }
        public string ime { get; set; }
        public string prezime { get; set; }
        public string polaziste { get; set; }
        public string odrediste { get; set; }
        public string datumOdlaska { get; set; }
        public string datumPovratka { get; set; }
        public string trajanje { get; set; }
        public int prijevozId { get; set; }
        public string tipoviPrijevoza { get; set; }
    }
}
